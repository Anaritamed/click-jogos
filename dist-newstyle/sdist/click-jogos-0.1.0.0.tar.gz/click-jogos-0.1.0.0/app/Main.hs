module Main where

import MenuInicial (renderizaTelaInicial)

main :: IO()
main = renderizaTelaInicial